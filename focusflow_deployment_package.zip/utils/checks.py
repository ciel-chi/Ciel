import discord
from discord.ext import commands


def premium_required():
    async def predicate(ctx):
        user = ctx.author
        if user.premium_since:
            return True
        role = discord.utils.get(user.roles, name=ctx.bot.premium_role_name)
        if role:
            return True
        raise commands.CheckFailure(
            f"⭐ This requires **{ctx.bot.premium_role_name}**! Use `/premium` to upgrade."
        )
    return commands.check(predicate)
