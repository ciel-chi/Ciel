import os
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy import text

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///focusflow.db")

# Railway and Render sometimes provide postgres:// instead of postgresql+asyncpg://
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+asyncpg://", 1)
elif DATABASE_URL.startswith("postgresql://") and not DATABASE_URL.startswith("postgresql+"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://", 1)

engine = create_async_engine(DATABASE_URL, echo=False, future=True)


def _convert_query(query: str, args: tuple):
    """Convert aiosqlite-style ? placeholders to SQLAlchemy named params."""
    if "?" not in query:
        return query, {}
    parts = query.split("?")
    new_query = parts[0]
    params = {}
    for i, part in enumerate(parts[1:], 1):
        new_query += f":p{i}" + part
        params[f"p{i}"] = args[i - 1]
    return new_query, params


class DBManager:
    async def execute(self, query: str, *args):
        q, params = _convert_query(query, args)
        async with engine.begin() as conn:
            await conn.execute(text(q), params)

    async def fetchone(self, query: str, *args):
        q, params = _convert_query(query, args)
        async with engine.connect() as conn:
            result = await conn.execute(text(q), params)
            return result.fetchone()

    async def fetchall(self, query: str, *args):
        q, params = _convert_query(query, args)
        async with engine.connect() as conn:
            result = await conn.execute(text(q), params)
            return result.fetchall()

    async def init_db(self):
        is_sqlite = "sqlite" in DATABASE_URL

        if is_sqlite:
            await self.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    total_minutes INTEGER DEFAULT 0,
                    streak INTEGER DEFAULT 0,
                    last_study TEXT,
                    theme_color TEXT DEFAULT '339af0'
                )
            """)
            await self.execute("""
                CREATE TABLE IF NOT EXISTS flashcards (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    front TEXT,
                    back TEXT,
                    category TEXT DEFAULT 'General'
                )
            """)
            await self.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    channel_id INTEGER,
                    topic TEXT,
                    minutes INTEGER,
                    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
        else:
            # PostgreSQL schema
            await self.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id BIGINT PRIMARY KEY,
                    total_minutes INTEGER DEFAULT 0,
                    streak INTEGER DEFAULT 0,
                    last_study TEXT,
                    theme_color TEXT DEFAULT '339af0'
                )
            """)
            await self.execute("""
                CREATE TABLE IF NOT EXISTS flashcards (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT,
                    front TEXT,
                    back TEXT,
                    category TEXT DEFAULT 'General'
                )
            """)
            await self.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT,
                    channel_id BIGINT,
                    topic TEXT,
                    minutes INTEGER,
                    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
