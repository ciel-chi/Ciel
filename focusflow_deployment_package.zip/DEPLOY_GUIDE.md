# FocusFlow Deployment Guide (Railway & Render)

## ⚠️ CRITICAL: Why You Must Switch from SQLite

Railway and Render use **ephemeral filesystems**. This means:
- Your `focusflow.db` file is deleted on every redeploy, restart, or platform maintenance.
- **All user data (flashcards, study stats) would vanish.**

**Solution:** Use the included `database.py`, which auto-detects `DATABASE_URL` and switches to **PostgreSQL** in production while keeping SQLite for local development.

---

## 🚀 Option 1: Railway (Recommended for Production)

**Why Railway?**
- Usage-based pricing (~$1–5/mo for a small bot). citeweb_search:2#5
- No sleep mode. Once deployed, it stays online 24/7.
- Native PostgreSQL with one click.
- Auto-deploys when you push to GitHub.

### Step-by-Step

1. **Push your code to GitHub**
   - Create a repo (e.g., `focusflow-bot`).
   - Upload these files (include `requirements.txt`, `Procfile`, `runtime.txt`, `railway.toml`, and the code).

2. **Create a Railway account**
   - Go to [railway.app](https://railway.app) and sign up.

3. **Create a New Project**
   - Click **New Project** → **Deploy from GitHub repo**.
   - Select your `focusflow-bot` repository.
   - Railway will auto-detect Python and install dependencies via `requirements.txt`.

4. **Add PostgreSQL**
   - In your project dashboard, click **New** → **Database** → **Add PostgreSQL**.
   - Railway automatically creates it and injects a `DATABASE_URL` environment variable into your app.

5. **Set Environment Variables**
   - Go to your **focusflow-bot service** → **Variables** tab.
   - Add:
     - `DISCORD_TOKEN` = your bot token
     - `PREMIUM_ROLE_NAME` = `FocusFlow Premium`
     - `FREE_FLASHCARD_LIMIT` = `50`
   - **Do NOT** add `DATABASE_URL` manually — Railway already injected it from the PostgreSQL addon.

6. **Deploy**
   - Railway deploys automatically. Check the **Deploys** tab for logs.
   - Look for: `✅ FocusFlow online as YourBot#1234`.

7. **(Optional) Custom Domain / Health Checks**
   - If you add a web dashboard later, Railway can give you a public URL.
   - For a pure bot (WebSocket), no web server is needed.

---

## 🧪 Option 2: Render (Good for Testing / Hobby)

**Why Render?**
- Has a **free tier** (750 hours/month). citeweb_search:2#2
- Simple dashboard, very similar to old Heroku.

**The Catch:**
- **Free tier services sleep after 15 minutes of inactivity.** Your bot will go offline and need a manual wake-up or ping hack. citeweb_search:2#2
- For a production bot that earns money, upgrade to the **$7/month Background Worker** plan for always-on uptime. citeweb_search:2#0

### Step-by-Step

1. **Push your code to GitHub** (same as above).

2. **Create a Render account**
   - Go to [render.com](https://render.com).

3. **Create a Background Worker**
   - Click **New** → **Background Worker**.
   - **Important:** Select **Background Worker**, NOT "Web Service". Discord bots do not need an HTTP server.
   - Connect your GitHub repo.

4. **Configure Build & Start**
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python main.py`
   - Select **Python 3** environment.

5. **Add PostgreSQL**
   - Click **New** → **PostgreSQL**.
   - Copy the **Internal Database URL**.
   - Paste it into your Background Worker’s **Environment** tab as `DATABASE_URL`.

6. **Set Remaining Environment Variables**
   - `DISCORD_TOKEN`
   - `PREMIUM_ROLE_NAME`
   - `FREE_FLASHCARD_LIMIT`

7. **Deploy**
   - Render builds and starts your worker. View logs in the **Logs** tab.

---

## 🔧 Environment Variable Reference

| Variable | Local Dev | Railway | Render |
|----------|-----------|---------|--------|
| `DISCORD_TOKEN` | ✅ Required | ✅ Required | ✅ Required |
| `DATABASE_URL` | Optional (defaults to SQLite) | ✅ Auto-injected by PostgreSQL addon | ✅ Paste from PostgreSQL dashboard |
| `PREMIUM_ROLE_NAME` | ✅ Required | ✅ Required | ✅ Required |
| `FREE_FLASHCARD_LIMIT` | ✅ Required | ✅ Required | ✅ Required |

---

## 🧪 Testing Locally (Before Deploying)

```bash
# 1. Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2. Install deps
pip install -r requirements.txt

# 3. Create .env file (use .env.example as template)
cp .env.example .env
# Edit .env and add your DISCORD_TOKEN

# 4. Run
python main.py
```

If it prints `✅ FocusFlow online as ...`, your code is ready to deploy.

---

## 🛠️ Troubleshooting

| Problem | Cause | Fix |
|---------|-------|-----|
| `ModuleNotFoundError: discord` | Dependencies not installed | Ensure `requirements.txt` is committed to GitHub |
| `Database disconnected` | `DATABASE_URL` missing or malformed | Check that PostgreSQL addon is provisioned and linked |
| Bot offline after 15 min | Render free tier sleep mode | Upgrade to Render Starter ($7/mo) or switch to Railway |
| `asyncpg` install fails | Missing system libs | Railway/Render handle this; locally install `libpq-dev` (Linux) or use `psycopg` instead |
| Commands not appearing | Slash commands not synced | Wait up to 1 hour, or re-invite bot with `applications.commands` scope |

---

## 💰 Cost Summary (2026)

| Platform | Free Tier | Production Cost | Best For |
|----------|-----------|-----------------|----------|
| **Railway** | $5 trial credit, then ~$1/mo minimum | ~$3–8/mo for small bot + Postgres | 24/7 production bots |
| **Render** | 750 hrs/mo (sleeps after 15 min) | $7/mo worker + ~$7/mo Postgres | Testing, hobby projects |
| **Hetzner VPS** | None | ~€3–5/mo | Full control, cheapest long-term |

For a bot you plan to monetize, **Railway Hobby** or a **$5 Hetzner VPS** is the best value. citeweb_search:2#1
