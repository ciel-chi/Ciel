import discord
from discord import app_commands
from discord.ext import commands
import random
import asyncio
from datetime import datetime, timedelta
from utils.checks import premium_required


class Study(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def is_premium(self, user: discord.Member) -> bool:
        if user.premium_since:
            return True
        return discord.utils.get(user.roles, name=self.bot.premium_role_name) is not None

    @commands.hybrid_command(name="pomodoro", description="Start a focused study session")
    @app_commands.describe(minutes="5-120 minutes", topic="What are you working on?")
    async def pomodoro(self, ctx, minutes: int = 25, *, topic: str = "Studying"):
        if not 5 <= minutes <= 120:
            return await ctx.send("Keep sessions between 5 and 120 minutes!", ephemeral=True)

        embed = discord.Embed(
            title="🍅 Pomodoro Started",
            description=f"**{ctx.author.display_name}** is focusing on **{topic}** for **{minutes} min**",
            color=0xff6b6b
        )
        msg = await ctx.send(embed=embed)

        await self.bot.db.execute(
            "INSERT INTO users (user_id) VALUES (:p1) ON CONFLICT(user_id) DO NOTHING",
            ctx.author.id
        )
        await self.bot.db.execute(
            "INSERT INTO sessions (user_id, channel_id, topic, minutes) VALUES (:p1, :p2, :p3, :p4)",
            ctx.author.id, ctx.channel.id, topic, minutes
        )

        await asyncio.sleep(minutes * 60)

        embed.title = "✅ Session Complete!"
        embed.description = f"Nice work, {ctx.author.mention}! You crushed **{minutes} minutes** of **{topic}**."
        embed.color = 0x51cf66
        await msg.edit(embed=embed)

        await self.bot.db.execute(
            "UPDATE users SET total_minutes = total_minutes + :p1 WHERE user_id = :p2",
            minutes, ctx.author.id
        )

    @commands.hybrid_command(name="flashcard", description="Create, list, or quiz yourself")
    @app_commands.describe(action="create | list | quiz", content="For create: Question | Answer")
    async def flashcard(self, ctx, action: str, *, content: str = None):
        action = action.lower()

        if action == "create":
            if not content or "|" not in content:
                return await ctx.send("Format: `/flashcard create What is the powerhouse of the cell? | Mitochondria`")

            front, back = content.split("|", 1)

            row = await self.bot.db.fetchone(
                "SELECT COUNT(*) FROM flashcards WHERE user_id = :p1", ctx.author.id
            )
            count = row[0]

            if count >= self.bot.free_flashcard_limit and not self.is_premium(ctx.author):
                return await ctx.send(
                    f"🚫 Free limit reached (**{self.bot.free_flashcard_limit}** cards). "
                    f"Upgrade to Premium for unlimited flashcards! `/premium`"
                )

            await self.bot.db.execute(
                "INSERT INTO flashcards (user_id, front, back) VALUES (:p1, :p2, :p3)",
                ctx.author.id, front.strip(), back.strip()
            )
            await ctx.send(f"✅ Card **#{count + 1}** saved!")

        elif action == "list":
            rows = await self.bot.db.fetchall(
                "SELECT front, back, category FROM flashcards WHERE user_id = :p1",
                ctx.author.id
            )
            if not rows:
                return await ctx.send("No flashcards yet. Create some with `/flashcard create`")

            embed = discord.Embed(title=f"🗂️ {ctx.author.display_name}'s Deck", color=0x339af0)
            for front, back, cat in rows[:10]:
                embed.add_field(name=f"[{cat}] {front}", value=f"||{back}||", inline=False)
            if len(rows) > 10:
                embed.set_footer(text=f"+ {len(rows) - 10} more cards")
            await ctx.send(embed=embed)

        elif action == "quiz":
            row = await self.bot.db.fetchone(
                "SELECT front, back FROM flashcards WHERE user_id = :p1 ORDER BY RANDOM() LIMIT 1",
                ctx.author.id
            )
            if not row:
                return await ctx.send("No cards to quiz! Add some first.")

            await ctx.send(f"🧠 **Question:** {row[0]}\nReply with your answer (30s)!")

            def check(m):
                return m.author == ctx.author and m.channel == ctx.channel

            try:
                msg = await self.bot.wait_for("message", check=check, timeout=30.0)
                if msg.content.lower() == row[1].lower():
                    await ctx.send("🎉 Correct!")
                else:
                    await ctx.send(f"❌ Nope! Answer: **{row[1]}**")
            except asyncio.TimeoutError:
                await ctx.send("⏰ Time's up!")

    @commands.hybrid_command(name="stats", description="View your study statistics")
    async def stats(self, ctx):
        row = await self.bot.db.fetchone(
            "SELECT total_minutes, streak, theme_color FROM users WHERE user_id = :p1",
            ctx.author.id
        )

        if not row or row[0] is None:
            return await ctx.send("No data yet! Start a `/pomodoro` session.")

        minutes, streak, color = row
        hours = minutes // 60

        embed = discord.Embed(
            title=f"📊 {ctx.author.display_name}'s Focus Stats",
            color=int(color, 16) if color else 0x339af0
        )
        embed.add_field(name="Study Time", value=f"**{hours}h {minutes % 60}m**", inline=True)
        embed.add_field(name="Streak", value=f"🔥 **{streak} days**", inline=True)

        if self.is_premium(ctx.author):
            fc_row = await self.bot.db.fetchone(
                "SELECT COUNT(*) FROM flashcards WHERE user_id = :p1", ctx.author.id
            )
            fc_count = fc_row[0]
            sess_row = await self.bot.db.fetchone(
                "SELECT COUNT(*) FROM sessions WHERE user_id = :p1", ctx.author.id
            )
            sess_count = sess_row[0]
            embed.add_field(name="Flashcards", value=str(fc_count), inline=True)
            embed.add_field(name="Sessions", value=str(sess_count), inline=True)
            embed.set_footer(text="⭐ Premium Analytics Enabled")
        else:
            embed.set_footer(text="Upgrade to Premium for detailed analytics! /premium")

        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Study(bot))
