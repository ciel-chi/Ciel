import discord
from discord import app_commands
from discord.ext import commands
from utils.checks import premium_required


class Premium(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(name="premium", description="View FocusFlow Premium perks")
    async def premium(self, ctx):
        embed = discord.Embed(
            title="⭐ FocusFlow Premium",
            description="Unlock your full potential.",
            color=0xffd43b
        )
        embed.add_field(
            name="Free Plan",
            value="• Pomodoro timer
• 50 flashcards
• Basic stats
• Group study rooms",
            inline=True
        )
        embed.add_field(
            name="Premium — $4.99/mo",
            value="• **Unlimited** flashcards
• AI Tutor (`/ai_tutor`)
• Advanced analytics
• Custom themes (`/theme`)
• Priority support",
            inline=True
        )
        embed.add_field(
            name="How to Upgrade",
            value="• Subscribe via Server Settings → Subscriptions
• Or visit our billing portal
• Role is assigned automatically!",
            inline=False
        )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="ai_tutor", description="Ask the AI study assistant (Premium)")
    @premium_required()
    async def ai_tutor(self, ctx, *, question: str):
        await ctx.send(
            f"🤖 **AI Tutor:** *This is a placeholder.*\n"
            f"In production, send `{question}` to OpenAI and return the answer here.\n"
            f"Premium users get 100 queries/day."
        )

    @commands.hybrid_command(name="theme", description="Customize your stat card color (Premium)")
    @premium_required()
    async def theme(self, ctx, hex_color: str):
        hex_color = hex_color.lstrip("#")
        if len(hex_color) != 6:
            return await ctx.send("Use a valid hex code like `#51cf66`")
        await self.bot.db.execute(
            "UPDATE users SET theme_color = :p1 WHERE user_id = :p2",
            hex_color, ctx.author.id
        )
        embed = discord.Embed(
            title="🎨 Theme Updated",
            color=int(hex_color, 16)
        )
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Premium(bot))
