import discord
from discord.ext import commands
import os
from dotenv import load_dotenv
from database import DBManager, engine

load_dotenv()


class FocusFlow(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix="!",
            intents=discord.Intents.default(),
            help_command=None
        )
        self.premium_role_name = os.getenv("PREMIUM_ROLE_NAME", "FocusFlow Premium")
        self.free_flashcard_limit = int(os.getenv("FREE_FLASHCARD_LIMIT", 50))

    async def setup_hook(self):
        self.db = DBManager()
        await self.db.init_db()
        await self.load_extension("cogs.study")
        await self.load_extension("cogs.premium")

    async def on_ready(self):
        print(f"✅ FocusFlow online as {self.user}")
        await self.tree.sync()

    async def close(self):
        await engine.dispose()
        await super().close()


bot = FocusFlow()
bot.run(os.getenv("DISCORD_TOKEN"))
